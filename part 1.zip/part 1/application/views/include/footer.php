<!--[if lt IE 9]>


<script src="<?=base_url('public/global/plugins/respond.min.js')?>"></script>
<![endif]-->
    <!-- BEGIN CORE PLUGINS -->
<script src="<?=base_url('public/js/jquery.min.js')?>" type="text/javascript"></script>
<script src="<?=base_url('public/global/plugins/bootstrap/js/bootstrap.min.js')?>" type="text/javascript"></script>

<script type="text/javascript" src="<?=base_url('public/js/bootstrap-slider.min.js')?>"></script>
<script src="<?=base_url('public/global/plugins/js.cookie.min.js')?>" type="text/javascript"></script>
<script src="<?=base_url('public/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js')?>" type="text/javascript"></script>
<script src="<?=base_url('public/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js')?>" type="text/javascript"></script>
<script src="<?=base_url('public/js/fileinput.min.js')?>" type="text/javascript"></script>
<!-- END CORE PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<script src="<?=base_url('public/global/plugins/moment.min.js')?>" type="text/javascript"></script>
<script src="<?=base_url('public/global/plugins/flot/jquery.flot.min.js')?>" type="text/javascript"></script>
<script src="<?=base_url('public/global/plugins/flot/jquery.flot.resize.min.js')?>" type="text/javascript"></script>
<script src="<?=base_url('public/global/plugins/flot/jquery.flot.categories.min.js')?>" type="text/javascript"></script>
<script src="<?=base_url('public/global/plugins/jquery-easypiechart/jquery.easypiechart.min.js')?>" type="text/javascript"></script>
<script src="<?=base_url('public/global/plugins/jquery.sparkline.min.js')?>" type="text/javascript"></script>
<!-- END PAGE LEVEL PLUGINS -->
<!-- BEGIN THEME GLOBAL SCRIPTS -->
<script src="<?=base_url('public/global/scripts/app.min.js')?>" type="text/javascript"></script>
<!-- END THEME GLOBAL SCRIPTS -->
<!-- END PAGE LEVEL SCRIPTS -->
<!-- BEGIN THEME LAYOUT SCRIPTS -->
<script src="<?=base_url('public/layouts/layout/scripts/layout.min.js')?>" type="text/javascript"></script>
<script src="<?=base_url('public/layouts/global/scripts/quick-sidebar.min.js')?>" type="text/javascript"></script>
<!-- END THEME LAYOUT SCRIPTS -->
