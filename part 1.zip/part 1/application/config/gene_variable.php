<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['filename'] = '';
$config['genes']='';
$config['recordNum']='';
$config['Sample']='';
$config['YL']='';
$config['YH']='';