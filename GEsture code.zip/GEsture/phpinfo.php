<?php phpinfo();  
